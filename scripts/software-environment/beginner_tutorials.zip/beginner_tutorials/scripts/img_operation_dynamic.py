#!/usr/bin/env python
"""
ENAE 788M:  Hands-On Autonomous Aerial Robotics
ROS Tutorial: Image publisher subscriber with DYNAMIC RECONFIGURE

Author(s):
Prateek Arora(pratique<at>terpmail.umd.edu), Abhinav Modi(abhi1625<at>umd.edu)
M.Engg Robotics,
University of Maryland, College Park

"""

import sys, time

# numpy and scipy
import numpy as np

# OpenCV
import cv2

# Ros libraries
import roslib
import rospy

# Ros Messages
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
#For dynamic reconfiguration of parameters 
from dynamic_reconfigure.server import Server
from beginner_tutorials.cfg import TutorialsConfig

VERBOSE=False

class image_operation:

    def __init__(self):
        '''Initialize ros publisher, ros subscriber'''
        # topic where we publish
        self.image_pub = rospy.Publisher("/output/image_raw/compressed",
            Image, queue_size =5)
        
        # subscribed Topic
        self.subscriber = rospy.Subscriber("/cam0/image_raw",
            Image, self.callback,  queue_size = 5)

        # CvBridge object
        self.bridge = CvBridge()
        if VERBOSE :
            print "subscribed to /cam0/image_raw"
        self.param_path = '/threshold/'
        self.thresh = 0


    def callback(self, ros_data):
        '''Callback function of subscribed topic. '''
        if VERBOSE :
            print 'received image of type: "%s"' % ros_data.format

        #### direct conversion to CV2 ####
        cv_image = self.bridge.imgmsg_to_cv2(ros_data, "bgr8")
        print("shape of image = ", cv_image.shape)

        # Image operations
        
        # cv2.circle(cv_image,(512,512),50,(0,255,0),-1)

        # Image thresholding
        cv_image[cv_image < self.thresh]=0
        self.final_image = cv_image

        # Publish the image back
        # Note that this publisher is inside a subscriber callback!
        self.image_pub.publish(self.bridge.cv2_to_imgmsg(self.final_image, "bgr8"))



    def dynamic_cbk(self, config, level):
        # Another callback to fetch dynamic variable
        self.thresh = config.thresh
        return config


    def main(self):
        # Initialize the node
        rospy.init_node("threshold_dynamic", anonymous = False)
        # Start server for dynamic reconfigure
        srv = Server(TutorialsConfig, self.dynamic_cbk)

        # r = rospy.Rate(100) #100 Hz
        while not rospy.is_shutdown():
            rospy.spin()
            # r.sleep()

if __name__ == "__main__":
    try:
        obj = image_operation()
        obj.main()
    except rospy.ROSInterruptException:
        pass